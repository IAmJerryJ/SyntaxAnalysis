/**
 * HasLang syntax analyser.
 *
 * Copyright 2021, Anthony Sloane, Matthew Roberts, Kym Haines, Macquarie University, All rights reserved.
 */

package haslang

import org.bitbucket.inkytonik.kiama.parsing.Parsers
import org.bitbucket.inkytonik.kiama.util.Positions

/**
 * Module containing parsers for HasLang.
 */
class SyntaxAnalysis (positions : Positions) extends Parsers (positions) {

    import HasLangTree._
    import scala.language.postfixOps

    lazy val parser : PackratParser[Program] =
        phrase (program)

    lazy val program : PackratParser[Program] =
        exp ^^ Program

    lazy val literal : PackratParser[Exp] =
        "false" ^^^ BoolExp (false) |
        "true" ^^^ BoolExp (true) |
        integer ^^ (s => IntExp (s.toInt))

    lazy val factor : PackratParser[Exp] =
        // FIXME
        literal |
        identifier ^^ IdnUse |
        "(" ~> exp <~ ")" |
        failure ("exp expected")

    // FIXME   add parsers between factor and exp

    lazy val exp : PackratParser[Exp] =
        // FIXME
        factor

    lazy val definitions : PackratParser[Vector[Defn]] =
        // FIXME
        "fixme" ^^^ Vector()

    lazy val defn : PackratParser[Defn] =
        // FIXME
        "fixme" ^^^ Defn(IdnDef("fixme", IntType()), Vector())

    lazy val funline : PackratParser[FunLine] =
        // FIXME
        "fixme" ^^^ FunLine("", Vector(), IntExp(42))

    lazy val pat : PackratParser[Pat] =
        // FIXME
        basicpat

    lazy val basicpat : PackratParser[Pat] =
        // FIXME
        literal ^^ LiteralPat

    lazy val tipe : PackratParser[Type] =
        // FIXME
        basictipe

    lazy val basictipe : PackratParser[Type] =
        // FIXME
        "int" ^^^ IntType()

    // NOTE: You should not change anything below here...

    lazy val integer =
        regex ("[0-9]+".r)

    lazy val idndef =
        (identifier <~ "::") ~ tipe ^^ IdnDef

    val keywordStrings =
        List ("let", "else", "false", "if", "then", "true", "in")

    lazy val keyword =
        keywords ("[^a-zA-Z0-9_]".r, keywordStrings)

    lazy val identifier =
        not (keyword) ~> identifierBase

    lazy val identifierBase =
        regex ("[a-zA-Z][a-zA-Z0-9_]*".r) |
        failure ("identifier expected")

    lazy val whitespaceParser : PackratParser[Any] =
        rep ( """\s""".r | comment)

    lazy val comment : PackratParser[Any] =
        "{-" ~ rep (not ("-}") ~ (comment | any)) ~ "-}" |
        "--.*(\n|\\z)".r

}
